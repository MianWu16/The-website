
package cw3interfaces;

import java.util.ArrayList;

//**DO NOT CHANGE ANYTHING HERE
public interface VolunteerInterface {

    public String getSkillSet();
    
}

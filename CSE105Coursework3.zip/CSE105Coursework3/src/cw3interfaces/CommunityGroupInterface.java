

package cw3interfaces;

//**DO NOT CHANGE ANYTHING HERE
public interface CommunityGroupInterface {
    
    public int howManyVolunteers();
    public String getSkillsTotals();
}

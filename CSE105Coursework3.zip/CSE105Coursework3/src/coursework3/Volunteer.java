//DO NOT CHANGE THIS PACKAGE
package coursework3;

import cw3interfaces.VolunteerInterface;
//DO NOT CHANGE THIS NAME
public class Volunteer implements VolunteerInterface {
     private String skill;
//COMPLETE THIS CLASS      
     public Volunteer(String input){
      this.skill=input.toUpperCase();
   }
//these public methods need to form the interface 
// DO NOT CHANGE ANY OF THESE METHOD NAMES, RETURN VALUES, OR ARGUMENTS   
    @Override
    public String getSkillSet(){
        //COMPLETE CODE HERE
        //returns a String of this volunteers skills, eg BBB, ABC, CDD etc
        return skill;
    }
}

package coursework3;

import java.util.Iterator;
import java.util.Scanner;

/*READ ME: Use this class as your main class, and create your menu here
Your menu should then call the appropriate methods in the SkillSorter class
You need to complete the other classes, including the empty methods.
/*
 */
public class CW3Main {

    SkillSorter SS = new SkillSorter();
    FileHandler FH = new FileHandler();

    public static void main(String[] args) {
        CW3Main controller = new CW3Main();
    }

    public CW3Main() {
        SS.init();
        menu();
    }
    //Construct and run your menu here.
    //You MUST call methods in SkillSorter from your menu
    //and complete the methods in SkillSorter 
    //DO NOT write the methods, eg addVolunteer, in THIS class.
    //Call and use the ones in SkillSorter.
    private void menu() {
        boolean exit = false;
        int from = 0;
        int to = 0;
        for (int i = 0; i < 5; i++) {
                  FH.storeObjects(SS.getCommunityGroups().get(i).Vol, i + 1);
                  System.out.println("Group " + (i + 1) + " load succeed. ");
        }
        
        Volunteer select = null;
        while (!exit) {
            int choice = getMenuChoice();
            switch (choice) {
                case 1:
                    SS.addVolunteer(getVolunteer());
                    System.out.println("The volunteer was added");
                    break;
                case 2:
                    from = getGroupFrom();
                    to = getGroupTo();
                    select = getVolunteerMessage(SS.getCommunityGroups().get(from));
                    SS.moveVolunteer(select.getSkillSet(), SS.getCommunityGroups().get(from), SS.getCommunityGroups().get(to));
                    break;
                case 3:
                    from = getGroupFrom();
                    select = getVolunteerMessage(SS.getCommunityGroups().get(from));
                    SS.deleteVolunteer(select.getSkillSet(), SS.getCommunityGroups().get(from));
                    break;
                case 4:
                    SS.deleteAllVolunteers();
                    System.out.println("All people were cleared");
                    break;
                case 5://生成wen'j
                    for (int i = 0; i < 5; i++) {
                        System.out.print("Group" + (i + 1) + ":" + SS.getCommunityGroups().get(i).getSkillsTotals() + "\n");
                    }
                   for (int i = 0; i < 5; i++) {
                        System.out.println("\nThe whole Group" + (i + 1) + "*******************");
                        boolean has = false;
                        int count = 0;
                        while (count < SS.getCommunityGroups().get(i).Vol.size() && !has) {
                            Volunteer v = SS.getCommunityGroups().get(i).Vol.get(count);
                            System.out.print(" " + v.getSkillSet());
                            count++;}
                            //if (count % 20 == 0) {
                            //System.out.print("\r\n");
                            //
                    }
                     break;
                case 6://保存文件并退出
                    for (int i = 0; i < 5; i++) {
                        FH.ReadingObject(SS.getCommunityGroups().get(i).Vol, i + 1);
                        System.out.println("Group " + (i + 1) + " saved succeed. ");
                         exit = true;
                        break;
                    }
                 
        
            }
        }
        System.out.println(" Exit from system. ");
    }

    private int getMenuChoice() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Please choose an option from 1-6.");
        System.out.println("********************\n 1=Add a volunteer       2=Move a volunteer 3=Delete a volunteer"
                + "\n 4=Delete all volunteers 5=Display all      6=Save and exit");
        int choice = sc.nextInt();
         
       if (choice < 7 && choice > 0) {
            return choice;
        } else {
            System.out.println("Wrong number, please input 1-6");
        }
        return choice;
        }
     
    private Volunteer getVolunteer() {
        Volunteer newVolunteer = new Volunteer("");
        boolean right = false;
        Scanner s = new Scanner(System.in);
        System.out.println("Please choose the skills (three letters from A-E)");
        while (!right) {
            String input = s.next();
            int count = 0;
            if (input.length() == 3) {
                for (int i = 0; i < 3; i++) {
                    char custom = input.charAt(i);
                    if ("A".equals(String.valueOf(custom)) || "B".equals(String.valueOf(custom))
                            || "C".equals(String.valueOf(custom)) || "D".equals(String.valueOf(custom)) || "E".equals(String.valueOf(custom))) {
                        count++;
                    }
                }
            }
            if (count == 3) {
                right = true;
            }
            if (right) {
                newVolunteer = new Volunteer(input);
            } else {
                System.out.println("Wrong input information,please input (three letters from A-E) again");
            }
        }
        return newVolunteer;
    }

    private int getGroupFrom() {
        int num = 0;
        boolean right = false;
        Scanner s = new Scanner(System.in);
        System.out.println("Please input Group number from 1-5 :");
        while (!right) {
            int input = s.nextInt();
            if (input < 6 && input > 0) {
                right = true;
                num = input - 1;
            } else {
                System.out.println("Wrong input plase input number 1-5");
            }
        }
        return num;
    }

    private int getGroupTo() {
        int gainnum = 0;
        boolean right = false;
        Scanner s = new Scanner(System.in);
        System.out.println("Please input Group the volunteer will go 1-5 :");
        while (!right) {
            int input = s.nextInt();
            if (input < 6 && input > 0) {
                right = true;
                gainnum = input - 1;
            } else {
                System.out.println("Wrong number.  Please input number from 1-5.");
            }
        }
        return gainnum;
    }

    private Volunteer getVolunteerMessage(CommunityGroup group) {   //This method intends to find the popursed people
        Volunteer select = null;
        boolean right = false;
        Iterator iter = group.Vol.iterator();
        while (!right) {
            select = getVolunteer();
            while (iter.hasNext() ) {
                Volunteer v = (Volunteer) iter.next();
                if (!right) {
                    System.out.println("Cannot find this volunteer.");
                } else {
                    System.out.println(" Succeed! ");
                }
            }
        }
        return select;
    }
}

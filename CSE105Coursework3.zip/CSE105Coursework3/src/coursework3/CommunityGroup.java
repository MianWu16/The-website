//DO NOT CHANGE THIS PACKAGE
package coursework3;

import cw3interfaces.CommunityGroupInterface;
import java.util.ArrayList;
import java.util.Iterator;


//DO NOT CHANGE THIS NAME
public class CommunityGroup implements CommunityGroupInterface {
    public ArrayList<Volunteer> Vol = new ArrayList<>();
    
    
 //COMPLETE THIS CLASS    
    public void init() {
        String randomskills = "ABCDE";
        for (int i = 0; i < 500; i++) {
            String newskill = "";
            for (int j = 0; j < 3; j++) {
                newskill = newskill + randomskills.charAt((int)(Math.random() * 5));
            }
            Vol.add(new Volunteer(newskill));
        }
    }
       
    
 //these public methods need to form the interface 
// DO NOT CHANGE ANY OF THESE METHOD NAMES, RETURN VALUES, OR ARGUMENTS   
    @Override
    public int howManyVolunteers(){
        //return the total number of volunteers in this community group
        //COMPLETE CODE HERE
        return Vol.size();
    }
    
    @Override
    public String getSkillsTotals(){
        // return the total number of each skill in a String, example:
        //Skill A: 13, Skill B: 20, Skill C: 23, Skill D: 5, Skill E: 41
        //COMPLETE CODE HERE
        boolean has = false;
        String output = "";
        String[] skillname = {"A", "B", "C", "D", "E"};
        int[] count = new int[5];
        int total = 0;
        Iterator iter = Vol.iterator();
        while (iter.hasNext()&&!has) {
            Volunteer v = (Volunteer) iter.next();
            String skill = String.valueOf(v.getSkillSet());
            for (int i = 0; i < 3; i++) {
                char str = skill.charAt(i);
                if ("A".equals(String.valueOf(str))) {
                    count[0]++;
                } else if ("B".equals(String.valueOf(str))) {
                    count[1]++;
                } else if ("C".equals(String.valueOf(str))) {
                    count[2]++;
                } else if ("D".equals(String.valueOf(str))) {
                    count[3]++;
                } else if ("E".equals(String.valueOf(str))) {
                    count[4]++;
                }
            }
        }
        //计数器
        for (int i = 0; i < 5; i++) {
            total = total + count[i];
            output = output + "\nSkill" + skillname[i] + ":" + count[i] + ",";
        }
        output = output + "\nTotal Skills are" + total;
        return output;
    }
}
    
    
    


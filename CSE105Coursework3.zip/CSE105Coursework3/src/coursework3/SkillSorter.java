//DO NOT CHANGE THIS PACKAGE
package coursework3;

import cw3interfaces.SkillSorterInterface;
import java.util.ArrayList;
import java.util.Iterator;




//DO NOT CHANGE THIS NAME
public class SkillSorter implements SkillSorterInterface{
    private ArrayList<CommunityGroup> myGroups = new ArrayList<>();
    
    //COMPLETE THIS CLASS
    public void init() {
        CommunityGroup[] groups = new CommunityGroup[5];
        for (int i = 0; i < 5; i++) {
            groups[i] = new CommunityGroup();
            groups[i].init(); 
            FileHandler.ReadingObject(groups[i].Vol, i + 1);
            myGroups.add(groups[i]);
        }
        ArrayList<Volunteer> allVolunteers = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            Iterator iter = myGroups.get(i).Vol.iterator();
            while (iter.hasNext()) {
                allVolunteers.add((Volunteer) (iter.next()));
            }
        }
        sortVolunteers(allVolunteers);
    }

    private int sum(Volunteer v) {
        int total = 0;
        int[] count = new int[5];
        String skill = String.valueOf(v.getSkillSet());
        for (int i = 0; i < 3; i++) {
            char str = skill.charAt(i);
            if ("A".equals(String.valueOf(str))) {
                count[0]++;
            } else if ("B".equals(String.valueOf(str))) {
                count[1]++;
            } else if ("C".equals(String.valueOf(str))) {
                count[2]++;
            } else if ("D".equals(String.valueOf(str))) {
                count[3]++;
            } else if ("E".equals(String.valueOf(str))) {
                count[4]++;
            }
        }
        total = 3 * count[0] + 3 * count[1] + 3 * count[2] + 3 * count[3] + 3 * count[4];
        return total;
    }

    public void sortVolunteers(ArrayList<Volunteer> group) {
        boolean has = false;
        int[] total = new int[group.size()];
        int counter = 0;
        Volunteer[] vBefore = new Volunteer[group.size()];
        Iterator iter = group.iterator();
        while (iter.hasNext() && !has) {
            Volunteer v = (Volunteer) iter.next();
            total[counter] = sum(v);
            vBefore[counter]=v;
            counter++;
        }
        for (int i = 1; i < total.length; i++) {
            for (int j = 0; j < total.length - i; j++) {
                if (total[j] < total[j + 1]) {
                    int swapSum = total[j];
                    total[j] = total[j + 1];
                    total[j + 1] = swapSum;
                    Volunteer swapVolunteer = vBefore[j];
                    vBefore[j] = vBefore[j + 1];
                    vBefore[j + 1] = swapVolunteer;
                }
            }
        }
          deleteAllVolunteers();
         counter=0;
        for(int i=0;i<vBefore.length;i++){
         if(counter+1>5){
         counter=0;}
         if(myGroups.get(counter).Vol.size()<=500){
            myGroups.get(counter).Vol.add(vBefore[i]);
            counter++;
       }
    }
    }
    
    
//these public methods need to form the interface 
// DO NOT CHANGE ANY OF THESE METHOD NAMES, RETURN VALUES, OR ARGUMENTS
    @Override
    public void addVolunteer(Volunteer vol){
        //add a volunteer to a Community Group USING YOUR SORTING ALGORITHM
        //COMPLETE CODE HERE
       ArrayList<Volunteer> allVolunteers = new ArrayList();
        for (int i = 0; i < 5; i++) {
            Iterator iter = myGroups.get(i).Vol.iterator();
            while (iter.hasNext()) {
                 allVolunteers.add((Volunteer)(iter.next()));
            }
        }
           allVolunteers.add(vol);
           sortVolunteers(allVolunteers); 
    }
    
    @Override
    public void moveVolunteer(String skillSet, CommunityGroup from, CommunityGroup to){
        //move a volunteer with this skillset (eg AAA, BCD) from one CommunityGroup to another
        //COMPLETE CODE HERE
         to.Vol.add(new Volunteer(skillSet));
        boolean has = false;
        int count = 0;
        while (count < from.Vol.size() && !has) {
            Volunteer v = from.Vol.remove(count);
            has = true;
        }
        count++;
    }
    
    @Override
    public void deleteVolunteer(String skillSet, CommunityGroup from){
        //delete a volunteer with this skillset from this CommunityGroup
        //COMPLETE CODE HERE
        int count = 0;
        while (count < from.Vol.size()  ) {
            Volunteer v = from.Vol.get(count);
            if (skillSet.equals(v.getSkillSet())) {
                from.Vol.remove(count);
                
            }
            count++;
        }
        System.out.print("The people who have"+skillSet+"has removed");
    }
    @Override
    public void deleteAllVolunteers(){
        // delete all volunteers from all CommunityGroups
        //COMPLETE CODE HERE
        myGroups.clear();
        for (int i = 0; i < 5; i++) {
            myGroups.add(new CommunityGroup());
        }
    }

    @Override
    public ArrayList<CommunityGroup> getCommunityGroups(){
        //return an ArrayList of all this application's CommunityGroups
        return myGroups;
    }
    
   
   
}

package coursework3;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ASUS
 */
public class FileHandler {
    public static void storeObjects(ArrayList<Volunteer> group, int groupname) {
        File file = new File("group" + groupname + "PersonFile.txt");
        try {
            BufferedWriter fw = new BufferedWriter(new FileWriter(file, false));
            for (Volunteer Vol : group) {
                fw.write(Vol.getSkillSet());
                fw.newLine();
            //    System.out.println("Person " + Vol.getSkillSet() + " written to file");
            }
            fw.flush();
            fw.close();
        } catch (IOException e) {
            System.out.println("Error writing to file");
        }
    }
    // TODO code application logic here
    public static boolean ReadingObject(ArrayList<Volunteer> group, int groupname) {
        File file = new File("group" + groupname + "PersonFile.txt");
        boolean success = false;
        String line = "";
        try {
            BufferedReader fr = new BufferedReader(new FileReader(file));
            while ((line = fr.readLine()) != null) {
                group.add(new Volunteer(line));
            }
            fr.close();     // close file
        } catch (IOException e) {
            System.out.println("Error reading file");
            success = false;
        }
        return success;
    }
}
